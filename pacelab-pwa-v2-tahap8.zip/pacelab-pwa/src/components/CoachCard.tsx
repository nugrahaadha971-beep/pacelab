import { Activity, AlertTriangle, ArrowRight, Heart, TrendingUp } from 'lucide-react';
import type { UserProfile, Workout } from '../analytics/types';
import { acwr, cardiacDrift, DAY_MS, efTrend } from '../analytics/workload';
import type { AcwrStatus } from '../analytics/workload';
import { velocityFor, ZONE_FRACTION } from '../analytics/predictor';
import { coachAdvice, DRIFT_WARN_PCT } from '../analytics/coachEngine';
import type { SessionRec } from '../analytics/coachEngine';
import { fmtPace } from '../plans/pace';

type PaceZoneKey = keyof typeof ZONE_FRACTION;

const SESSION_LABEL: Record<SessionRec, string> = {
  easy: 'Easy Run',
  tempo: 'Tempo Run',
  interval: 'Interval',
  long_run: 'Long Run',
  recovery: 'Recovery Run',
  rest: 'Istirahat',
};

const STATUS_BADGE: Record<AcwrStatus, { label: string; badge: string; pin: string; border: string }> = {
  unknown: {
    label: 'Data Belum Cukup',
    badge: 'bg-slate-400/15 text-slate-300 border-slate-400/25',
    pin: 'bg-slate-300 ring-slate-300/30',
    border: 'border-white/5',
  },
  undertraining: {
    label: 'Beban Rendah',
    badge: 'bg-sky-400/15 text-sky-300 border-sky-400/30',
    pin: 'bg-sky-400 ring-sky-400/35',
    border: 'border-sky-400/20',
  },
  sweet_spot: {
    label: 'Aman · Optimal',
    badge: 'bg-emerald-400/15 text-emerald-300 border-emerald-400/30',
    pin: 'bg-emerald-400 ring-emerald-400/35',
    border: 'border-emerald-400/20',
  },
  high_fatigue: {
    label: 'Terlalu Berat',
    badge: 'bg-coral/15 text-coral border-coral/30',
    pin: 'bg-coral ring-coral/35',
    border: 'border-coral/25',
  },
};

const PACE_ZONES: ReadonlyArray<{
  key: PaceZoneKey;
  name: string;
  desc: string;
  barPct: string;
  barColor: string;
  textColor: string;
  dotColor: string;
  hrFrac: [number, number];
}> = [
  {
    key: 'easy',
    name: 'Easy',
    desc: 'Napas tenang, bangun daya tahan dasar',
    barPct: '38%',
    barColor: 'bg-sky-400',
    textColor: 'text-sky-300',
    dotColor: 'bg-sky-400',
    hrFrac: [0.71, 0.82],
  },
  {
    key: 'marathon',
    name: 'Marathon',
    desc: 'Ritme stabil & efisien jangka panjang',
    barPct: '58%',
    barColor: 'bg-emerald-400',
    textColor: 'text-emerald-300',
    dotColor: 'bg-emerald-400',
    hrFrac: [0.80, 0.87],
  },
  {
    key: 'threshold',
    name: 'Threshold',
    desc: 'Batas ambang laktat terkontrol',
    barPct: '78%',
    barColor: 'bg-amber-400',
    textColor: 'text-amber-300',
    dotColor: 'bg-amber-400',
    hrFrac: [0.86, 0.91],
  },
  {
    key: 'interval',
    name: 'Interval',
    desc: 'Kecepatan tinggi & kapasitas VO2max',
    barPct: '96%',
    barColor: 'bg-coral',
    textColor: 'text-coral',
    dotColor: 'bg-coral',
    hrFrac: [0.90, 0.96],
  },
];

function formatBpmRange(frac: [number, number], maxHr: number | null): string | null {
  if (!maxHr || maxHr <= 0) return null;
  const lo = Math.ceil(frac[0] * maxHr - 1e-9);
  const hi = Math.ceil(frac[1] * maxHr - 1e-9);
  return `${lo}–${hi} bpm`;
}

/** Hitung posisi persentase marker pada pita ACWR skala 0.0 – 1.8. */
function acwrMarkerPct(ratio: number): number {
  const clamped = Math.max(0.05, Math.min(1.75, ratio));
  return (clamped / 1.8) * 100;
}

export function ZonaPaceCard({ vdot, maxHr }: { vdot: number; maxHr: number | null }) {
  return (
    <section
      aria-label="Zona Pace dan Intensitas"
      className="rounded-2xl border border-white/5 bg-navy-800 p-4 shadow-sm"
    >
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-bold tracking-tight text-slate-100">Zona Pace</h2>
          <p className="text-xs text-slate-400">Target kecepatan latihan berdasarkan kebugaran terkini</p>
        </div>
        <span className="shrink-0 rounded-full border border-sky-400/30 bg-sky-400/15 px-3 py-1 text-xs font-extrabold tabular-nums text-sky-300">
          VDOT {vdot.toFixed(1)}
        </span>
      </div>

      <div className="mt-4 space-y-3.5">
        {PACE_ZONES.map((z) => {
          const paceStr = fmtPace(60000 / velocityFor(vdot, ZONE_FRACTION[z.key]));
          const bpmStr = formatBpmRange(z.hrFrac, maxHr);
          return (
            <div key={z.key} className="rounded-xl border border-white/5 bg-navy-900/75 p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span aria-hidden className={`h-2 w-2 rounded-full ${z.dotColor}`} />
                    <span className="text-sm font-bold text-slate-100">{z.name}</span>
                  </div>
                  <p className="mt-0.5 text-xs text-slate-400">{z.desc}</p>
                </div>

                <div className="shrink-0 text-right tabular-nums">
                  <div className={`text-base font-extrabold ${z.textColor}`}>
                    {paceStr} <span className="text-xs font-semibold text-slate-400">/km</span>
                  </div>
                  {bpmStr && (
                    <div className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-medium text-slate-400">
                      <Heart className="h-3 w-3 text-slate-500" aria-hidden />
                      <span>{bpmStr}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-navy-700">
                <div
                  className={`h-full rounded-full ${z.barColor} transition-all duration-300`}
                  style={{ width: z.barPct }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export default function CoachCard({ workouts, profile }: { workouts: Workout[]; profile: UserProfile }) {
  const t = Date.now();
  const load = acwr(workouts, profile, t);
  const ef = efTrend(workouts, t);
  const last = [...workouts].sort((a, b) => b.date - a.date)[0];
  const drift = last ? cardiacDrift(last.laps) : null;
  const advice = coachAdvice({
    acwrStatus: load.status,
    acwrRatio: load.ratio,
    efImproving: ef.improving,
    lastType: last?.workoutType ?? null,
    daysSinceLast: last ? (t - last.date) / DAY_MS : null,
    lastDrift: drift,
  });
  const meta = STATUS_BADGE[load.status];
  const driftHigh = drift != null && drift > DRIFT_WARN_PCT;

  return (
    <div className="space-y-4">
      <section
        aria-label="Saran Pelatih"
        className={`rounded-2xl border bg-navy-800 p-4 shadow-sm ${meta.border}`}
      >
        {/* Header & Lencana Status */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-coral/15 text-coral">
              <Activity className="h-4 w-4" aria-hidden />
            </span>
            <h2 className="text-base font-bold tracking-tight text-slate-100">Saran Pelatih</h2>
          </div>

          <span
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-bold tabular-nums ${meta.badge}`}
          >
            <span aria-hidden className="h-1.5 w-1.5 rounded-full bg-current" />
            <span>
              {meta.label}
              {load.ratio != null ? ` · ${load.ratio.toFixed(2)}` : ''}
            </span>
          </span>
        </div>

        {/* Pita Spektrum ACWR (0.0 – 1.8) */}
        {load.ratio != null && (
          <div className="mt-4 rounded-xl border border-white/5 bg-navy-900/70 px-3 py-2.5">
            <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold text-slate-400">
              <span>Spektrum Beban (ACWR)</span>
              <span className="tabular-nums text-slate-200">Rasio {load.ratio.toFixed(2)}</span>
            </div>

            <div className="relative py-1.5">
              {/* 3 Segmen Zona: <0.8 (44.4%), 0.8-1.3 (27.8%), >1.3 (27.8%) */}
              <div className="flex h-2 w-full overflow-hidden rounded-full bg-navy-700">
                <div className="h-full bg-sky-400/75" style={{ width: '44.44%' }} />
                <div className="h-full bg-emerald-400" style={{ width: '27.78%' }} />
                <div className="h-full bg-coral/85" style={{ width: '27.78%' }} />
              </div>

              {/* Pin Penanda Posisi Aktual */}
              <div
                className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
                style={{ left: `${acwrMarkerPct(load.ratio)}%` }}
              >
                <span className={`block h-3.5 w-3.5 rounded-full border-2 border-navy-900 ring-4 ${meta.pin}`} />
              </div>
            </div>

            {/* Label batas sejajar dengan batas segmen: 0.8 = 44.44%, 1.3 = 72.22% */}
            <div className="relative mt-1 h-4 text-[10px] font-medium tabular-nums text-slate-400" aria-hidden>
              <span className="absolute left-0">0.0</span>
              <span className="absolute -translate-x-1/2" style={{ left: '44.44%' }}>0.8</span>
              <span className="absolute -translate-x-1/2" style={{ left: '72.22%' }}>1.3</span>
              <span className="absolute right-0">1.8</span>
            </div>
            <div className="mt-1 flex justify-between text-[10px] font-medium text-slate-400">
              <span className="text-sky-300">Rendah</span>
              <span className="text-emerald-300">Aman</span>
              <span className="text-coral">Berlebih</span>
            </div>
          </div>
        )}

        {/* Kalimat Rekomendasi */}
        <p className="mt-3.5 text-sm leading-relaxed text-slate-200">{advice.detail}</p>

        {/* Kotak Sorotan Sesi Berikutnya */}
        <div className="mt-3.5 flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-navy-900 px-3.5 py-2.5">
          <div className="min-w-0">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Rekomendasi Sesi Berikutnya
            </div>
            <div className="mt-0.5 flex flex-wrap items-center gap-2">
              <span className="text-sm font-bold text-slate-100">{SESSION_LABEL[advice.session]}</span>
              {advice.durationAddMin > 0 && (
                <span className="rounded-md bg-sky-400/15 px-2 py-0.5 text-xs font-extrabold tabular-nums text-sky-300">
                  +{advice.durationAddMin} menit
                </span>
              )}
            </div>
          </div>
          <ArrowRight className="h-4 w-4 shrink-0 text-slate-400" aria-hidden />
        </div>

        {/* Lencana Tren Aerobik & Cardiac Drift */}
        {(advice.efNote || drift != null) && (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {advice.efNote && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/25 bg-emerald-400/15 px-2.5 py-1 text-xs font-bold text-emerald-300">
                <TrendingUp className="h-3.5 w-3.5" aria-hidden />
                <span>{advice.efNote}</span>
              </span>
            )}

            {drift != null && (
              <span
                className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold tabular-nums ${
                  driftHigh
                    ? 'border-amber-400/30 bg-amber-400/15 text-amber-300'
                    : 'border-white/10 bg-navy-900 text-slate-300'
                }`}
              >
                {driftHigh && <AlertTriangle className="h-3.5 w-3.5" aria-hidden />}
                <span>Cardiac drift terakhir: {drift.toFixed(1)}%</span>
              </span>
            )}
          </div>
        )}
      </section>

    </div>
  );
}
